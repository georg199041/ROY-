-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 19 2012 г., 09:56
-- Версия сервера: 5.1.62-community
-- Версия PHP: 5.3.9-ZS5.6.0

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `sunny_roy`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_table` varchar(255) DEFAULT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_agent` text NOT NULL,
  `comment` text,
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contents_posts` (`ref_table`,`ref_id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `comments_comments`
--

DROP TABLE IF EXISTS `comments_comments`;
CREATE TABLE IF NOT EXISTS `comments_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(255) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_agent` text NOT NULL,
  `comment` text,
  `status` enum('MODERATED','NOTVIEWED','REJECTED') NOT NULL DEFAULT 'NOTVIEWED',
  `created_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `comments_comments`
--

INSERT INTO `comments_comments` (`id`, `table`, `table_id`, `name`, `email`, `ip`, `user_agent`, `comment`, `status`, `created_ts`) VALUES
(1, 'photogallery_albums', 1, 'Пётр Фролов', 'email@mail.ru', '192.168.1.1', 'Mozzzzzila', '<p>1Авторская программа реабилитации наркозависимых включает в себя\n				проживание в деревянных домиках в природных условиях, а так же\n				использование природных оздоровительных процедур.</p>', 'MODERATED', 1353066529),
(2, 'photogallery_albums', 1, 'Пётр Фролов2', 'email@mail.ru', '192.168.1.1', 'Mozzzzzila', '<p>2Авторская программа реабилитации наркозависимых включает в себя\n				проживание в деревянных домиках в природных условиях, а так же\n				использование природных оздоровительных процедур.</p>', 'MODERATED', 1353066541);

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_contacts`
--

DROP TABLE IF EXISTS `contacts_contacts`;
CREATE TABLE IF NOT EXISTS `contacts_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contacts_groups_id` int(11) DEFAULT NULL,
  `type` enum('ADDRESS','PHONE','EMAIL','SKYPE','LATLNG','QRCODE','IMAGE') NOT NULL DEFAULT 'ADDRESS',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `contacts_groups_id` (`contacts_groups_id`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `contacts_contacts`
--

INSERT INTO `contacts_contacts` (`id`, `contacts_groups_id`, `type`, `title`, `alias`, `description`, `image`, `enabled`) VALUES
(1, 1, 'ADDRESS', 'Адрес базы в крыму', 'crimea_address', '', '', 'YES'),
(2, 1, 'PHONE', 'Основной телефон', 'crimea_main_phone', '+38 (050) 545-33-69', '', 'YES'),
(3, 1, 'PHONE', 'Телефон', 'crimea_phone', '+38 (050) 545-33-69', NULL, 'NO'),
(4, 1, 'EMAIL', 'Эл. почта', 'crimea_email', 'admin@roy.com.uaфgetetre', '', 'YES'),
(5, 1, 'SKYPE', 'skype', 'crimea_skype', 'Che', '', 'YES'),
(6, 1, 'LATLNG', 'google', 'crimea_google', '45°17''14.77"С 34°44''1.81"В', NULL, 'YES'),
(7, 1, 'QRCODE', 'QR код', 'crimea_qr', NULL, '/uploads/crimea_qr.png', 'YES'),
(8, 2, 'ADDRESS', 'Адрес в Москве:', 'moscow_address', 'г.Москва, ул.Дубнинская д.14, к.2', NULL, 'YES'),
(9, 2, 'PHONE', 'Телефон в москве', 'moscow_main_phone', '+7 (495) 668-12-73', NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_groups`
--

DROP TABLE IF EXISTS `contacts_groups`;
CREATE TABLE IF NOT EXISTS `contacts_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `contacts_groups`
--

INSERT INTO `contacts_groups` (`id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, 'База в крыму', 'crimea_base', 'Живописное меcто Крыма расположено за селом Перевальное по пути из столицы Крыма - Симферополя - на Южный берег Крыма, трасса "Симферополь-Ялта".<br /><br />\r\nОт авто- или железнодорожного вокзала доехать маршруткой "Симферополь-Перевальное" до остановки "Красная пещера"или троллейбусами 51, 52, 53 до остановки "Стадион".<br /><br />\r\n<b>Или позвоните нам, и мы Вас встретим. </b>', 'YES'),
(2, 'Офис в Москве', 'moscow_office', NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_categories`
--

DROP TABLE IF EXISTS `contents_categories`;
CREATE TABLE IF NOT EXISTS `contents_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents_categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `alias` (`alias`),
  KEY `contents_categories_id` (`contents_categories_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `contents_posts`
--

DROP TABLE IF EXISTS `contents_posts`;
CREATE TABLE IF NOT EXISTS `contents_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents_categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `introtext` text,
  `fulltext` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `contents_categories_id` (`contents_categories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `contents_posts`
--

INSERT INTO `contents_posts` (`id`, `contents_categories_id`, `title`, `alias`, `introtext`, `fulltext`, `enabled`) VALUES
(1, NULL, 'О клубе', 'about_club', NULL, '<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <h2>Заголовок 2 уровня. Спортивный клуб «Рой»</h2>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма</h3>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ol>\r\n            <li>Профилактику и реабилитацию зависимостей любых видов (алко- и наркозависимостей, консультации психолога, лечение наркомании).</li>\r\n            <li>Курс восстановления после <a href="">перенесенных травм</a> суставов и сухожилий, при ослаблении организма, связанного с малоподвижным образом жизни и длительной работой на персональном компьютере.</li>\r\n            <li>Общее оздоровление с применением Индотебетской и Старославянской <a href="">практик с использованием.</a></li>\r\n        </ol>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ul>\r\n            <li>Лекарственных растений Крымских гор;</li>\r\n            <li>АПИ терапии (профилактика с применением пчелоукалывания);</li>\r\n            <li>Купание в живой воде горного водопада;</li>\r\n            <li>Массажные процедуры с применением масел природной среды и одновременной диагностикой организма.</li>\r\n        </ul>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление</h3>\r\n        <p>Методика, <strong>применяемая для реабилитации</strong> наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <blockquote><p>Цитата. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p></blockquote>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов.</p>', 'YES'),
(3, NULL, 'МИССИЯ И ЦЕЛИ', 'mission-and-goals', NULL, '<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <h2>Заголовок 2 уровня. Спортивный клуб «Рой»</h2>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма</h3>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ol>\r\n            <li>Профилактику и реабилитацию зависимостей любых видов (алко- и наркозависимостей, консультации психолога, лечение наркомании).</li>\r\n            <li>Курс восстановления после <a href="">перенесенных травм</a> суставов и сухожилий, при ослаблении организма, связанного с малоподвижным образом жизни и длительной работой на персональном компьютере.</li>\r\n            <li>Общее оздоровление с применением Индотебетской и Старославянской <a href="">практик с использованием.</a></li>\r\n        </ol>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ul>\r\n            <li>Лекарственных растений Крымских гор;</li>\r\n            <li>АПИ терапии (профилактика с применением пчелоукалывания);</li>\r\n            <li>Купание в живой воде горного водопада;</li>\r\n            <li>Массажные процедуры с применением масел природной среды и одновременной диагностикой организма.</li>\r\n        </ul>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление</h3>\r\n        <p>Методика, <strong>применяемая для реабилитации</strong> наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <blockquote><p>Цитата. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p></blockquote>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов.</p>', 'YES'),
(4, NULL, 'База клуба', 'club_base', NULL, '<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <h2>Заголовок 2 уровня. Спортивный клуб «Рой»</h2>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма</h3>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ol>\r\n            <li>Профилактику и реабилитацию зависимостей любых видов (алко- и наркозависимостей, консультации психолога, лечение наркомании).</li>\r\n            <li>Курс восстановления после <a href="">перенесенных травм</a> суставов и сухожилий, при ослаблении организма, связанного с малоподвижным образом жизни и длительной работой на персональном компьютере.</li>\r\n            <li>Общее оздоровление с применением Индотебетской и Старославянской <a href="">практик с использованием.</a></li>\r\n        </ol>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ul>\r\n            <li>Лекарственных растений Крымских гор;</li>\r\n            <li>АПИ терапии (профилактика с применением пчелоукалывания);</li>\r\n            <li>Купание в живой воде горного водопада;</li>\r\n            <li>Массажные процедуры с применением масел природной среды и одновременной диагностикой организма.</li>\r\n        </ul>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление</h3>\r\n        <p>Методика, <strong>применяемая для реабилитации</strong> наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <blockquote><p>Цитата. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p></blockquote>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов.</p>', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `core_sources`
--

DROP TABLE IF EXISTS `core_sources`;
CREATE TABLE IF NOT EXISTS `core_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `core_sources`
--

INSERT INTO `core_sources` (`id`, `name`) VALUES
(1, 'contents_categories'),
(2, 'contents_posts');

-- --------------------------------------------------------

--
-- Структура таблицы `default_sources`
--

DROP TABLE IF EXISTS `default_sources`;
CREATE TABLE IF NOT EXISTS `default_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `default_sources`
--

INSERT INTO `default_sources` (`id`, `name`) VALUES
(3, 'contacts_contacts'),
(1, 'contents_categories'),
(2, 'contents_posts');

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` varchar(2) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_pages`
--

DROP TABLE IF EXISTS `navigation_pages`;
CREATE TABLE IF NOT EXISTS `navigation_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `navigation_pages_id` int(11) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `type` enum('URI','MVC') NOT NULL DEFAULT 'URI',
  `uri` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `params` text,
  `route` varchar(255) DEFAULT NULL,
  `reset_params` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `encode_url` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`),
  KEY `navigation_pages_id` (`navigation_pages_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `navigation_pages`
--

INSERT INTO `navigation_pages` (`id`, `navigation_pages_id`, `label`, `type`, `uri`, `action`, `controller`, `module`, `params`, `route`, `reset_params`, `encode_url`, `order`, `enabled`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(2, NULL, 'Главное меню', 'URI', NULL, NULL, NULL, NULL, NULL, NULL, 'NO', 'NO', NULL, 'YES', NULL, NULL, NULL, 1352715212, NULL, 1352729548),
(3, 2, 'Главная', 'MVC', NULL, 'index', 'index', 'default', NULL, NULL, 'YES', 'NO', 1, 'YES', NULL, NULL, NULL, 1352715271, NULL, 1352729558),
(4, 2, 'О клубе', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"about_club"}', NULL, 'YES', 'NO', 2, 'YES', NULL, NULL, NULL, 1352715319, NULL, 1352794427),
(5, 2, 'Оздоровление и реабилитация', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"recovery_and_rehabilitation"}', NULL, 'YES', 'NO', 3, 'YES', NULL, NULL, NULL, 1352715581, NULL, 1352794432),
(6, 2, 'База клуба', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"club_base"}', NULL, 'YES', 'NO', 4, 'YES', NULL, NULL, NULL, 1352723440, NULL, 1352794438),
(7, 2, 'Контакты', 'MVC', NULL, 'index', 'index', 'contacts', NULL, NULL, 'YES', 'NO', 5, 'YES', NULL, NULL, NULL, 1352723500, NULL, 1352729652),
(8, 4, 'Слово Руководителя', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"according-to-head-of"}', NULL, 'YES', 'NO', 1, 'YES', NULL, NULL, NULL, 1352818173, NULL, NULL),
(9, 4, 'История', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"history"}', NULL, 'YES', 'NO', 2, 'YES', NULL, NULL, NULL, 1352818248, NULL, 1352818340),
(10, 4, 'Миссия и цели', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"mission-and-goals"}', NULL, 'YES', 'NO', 3, 'YES', NULL, NULL, NULL, 1352818297, NULL, NULL),
(11, 4, 'Документы', 'MVC', NULL, 'documents', 'index', 'contents', '', NULL, 'YES', 'NO', 4, 'YES', NULL, NULL, NULL, 1352818366, NULL, 1352818371),
(12, 4, 'Персонал', 'MVC', NULL, 'staff', 'index', 'contents', '', NULL, 'YES', 'NO', 5, 'YES', NULL, NULL, NULL, 1352818409, NULL, 1352818371),
(13, 4, 'Рекомендации', 'MVC', NULL, 'index', 'index', 'recommendations', NULL, 'recommendations', 'YES', 'NO', 6, 'YES', NULL, NULL, NULL, 1352818440, NULL, 1352991392),
(14, 6, 'Фотогалерея', 'MVC', NULL, 'index', 'index', 'photogallery', NULL, 'photogallery', 'YES', 'NO', 7, 'YES', NULL, NULL, NULL, 1353008102, NULL, 1353009353);

--
-- Триггеры `navigation_pages`
--
DROP TRIGGER IF EXISTS `BEFORE_INSERT_navigation_pages`;
DELIMITER //
CREATE TRIGGER `BEFORE_INSERT_navigation_pages` BEFORE INSERT ON `navigation_pages`
 FOR EACH ROW BEGIN
	SET `NEW`.`created_ts` = UNIX_TIMESTAMP();
	IF `NEW`.`checked_out_by` IS NOT NULL THEN
	    SET `NEW`.`checked_out_ts` = UNIX_TIMESTAMP();
	ELSE
	    SET `NEW`.`checked_out_ts` = NULL;
	END IF;
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `BEFORE_UPDATE_navigation_pages`;
DELIMITER //
CREATE TRIGGER `BEFORE_UPDATE_navigation_pages` BEFORE UPDATE ON `navigation_pages`
 FOR EACH ROW BEGIN
	SET `NEW`.`modified_ts` = UNIX_TIMESTAMP();
	IF `NEW`.`checked_out_by` IS NOT NULL THEN
	    SET `NEW`.`checked_out_ts` = UNIX_TIMESTAMP();
	ELSE
	    SET `NEW`.`checked_out_ts` = NULL;
	END IF;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_roles`
--

DROP TABLE IF EXISTS `navigation_roles`;
CREATE TABLE IF NOT EXISTS `navigation_roles` (
  `navigation_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  `type` enum('ALLOW','DENY') NOT NULL DEFAULT 'ALLOW',
  KEY `navigation_id` (`navigation_id`),
  KEY `roles_id` (`roles_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_roles`
--

INSERT INTO `navigation_roles` (`navigation_id`, `roles_id`, `type`) VALUES
(2, 1, 'ALLOW');

-- --------------------------------------------------------

--
-- Структура таблицы `params_names`
--

DROP TABLE IF EXISTS `params_names`;
CREATE TABLE IF NOT EXISTS `params_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `params_types_id` int(11) NOT NULL,
  `params_sources_id` int(11) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `params_types_id` (`params_types_id`),
  KEY `params_sources_id` (`params_sources_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `params_names`
--

INSERT INTO `params_names` (`id`, `name`, `params_types_id`, `params_sources_id`, `enabled`) VALUES
(1, 'additional_param', 3, NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `params_options`
--

DROP TABLE IF EXISTS `params_options`;
CREATE TABLE IF NOT EXISTS `params_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `params_names_id` int(11) NOT NULL,
  `option` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `params_names_id` (`params_names_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `params_relations`
--

DROP TABLE IF EXISTS `params_relations`;
CREATE TABLE IF NOT EXISTS `params_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `params_relations_id` int(11) DEFAULT NULL,
  `core_sources_id` int(11) NOT NULL,
  `core_sources_parentid` int(11) DEFAULT NULL,
  `params_names_id` int(11) NOT NULL,
  `inheritable` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `core_sources_id` (`core_sources_id`),
  KEY `params_names_id` (`params_names_id`),
  KEY `params_relations_id` (`params_relations_id`),
  KEY `core_sources_parentid` (`core_sources_parentid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `params_relations`
--

INSERT INTO `params_relations` (`id`, `params_relations_id`, `core_sources_id`, `core_sources_parentid`, `params_names_id`, `inheritable`) VALUES
(1, NULL, 2, NULL, 1, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `params_sources`
--

DROP TABLE IF EXISTS `params_sources`;
CREATE TABLE IF NOT EXISTS `params_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `core_sources_id` int(11) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `core_sources_id` (`core_sources_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `params_types`
--

DROP TABLE IF EXISTS `params_types`;
CREATE TABLE IF NOT EXISTS `params_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `source_required` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `params_types`
--

INSERT INTO `params_types` (`id`, `title`, `code`, `source_required`, `enabled`) VALUES
(1, NULL, 'SELECT', 'YES', 'YES'),
(2, NULL, 'MULTISELECT', 'YES', 'YES'),
(3, NULL, 'TEXT', 'NO', 'YES'),
(4, NULL, 'TEXTAREA', 'NO', 'YES'),
(5, NULL, 'CHECKBOX', 'NO', 'YES'),
(6, NULL, 'MULTICHECKBOX', 'YES', 'YES'),
(7, NULL, 'WYSWYG', 'NO', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `params_values`
--

DROP TABLE IF EXISTS `params_values`;
CREATE TABLE IF NOT EXISTS `params_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `core_sources_id` int(11) NOT NULL,
  `params_names_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `photogallery_albums`
--

DROP TABLE IF EXISTS `photogallery_albums`;
CREATE TABLE IF NOT EXISTS `photogallery_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photogallery_albums_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `photogallery_albums_id` (`photogallery_albums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `photogallery_albums`
--

INSERT INTO `photogallery_albums` (`id`, `photogallery_albums_id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, NULL, 'Тяжка работа мысли (test1)', 'test1', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(2, NULL, 'Журчит ручей (test2)', 'test2', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(3, NULL, 'Далекие дали (test3)', 'test3', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(4, NULL, 'Шаолинь как он есть (test4)', 'test4', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(5, NULL, 'Тыгдынские кони (test5)', 'test5', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(6, NULL, 'Дали но чуть поближе (test6)', 'test6', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `photogallery_images`
--

DROP TABLE IF EXISTS `photogallery_images`;
CREATE TABLE IF NOT EXISTS `photogallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photogallery_albums_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `cover` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `created_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `photogallery_albums_id` (`photogallery_albums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `photogallery_images`
--

INSERT INTO `photogallery_images` (`id`, `photogallery_albums_id`, `title`, `description`, `image`, `enabled`, `cover`, `created_ts`) VALUES
(1, 1, 'test cover1', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100),
(2, 2, 'test cover2', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album2/image.jpg', 'YES', 'NO', 200),
(3, 3, 'test cover3', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album3/image.jpg', 'YES', 'NO', 300),
(4, 4, 'test cover4', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album4/image.jpg', 'YES', 'NO', 400),
(5, 5, 'test cover5', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album5/image.jpg', 'YES', 'NO', 400),
(6, 6, 'test cover6', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album6/image.jpg', 'YES', 'NO', 400);

-- --------------------------------------------------------

--
-- Структура таблицы `recommendations_posts`
--

DROP TABLE IF EXISTS `recommendations_posts`;
CREATE TABLE IF NOT EXISTS `recommendations_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `recommendations_posts`
--

INSERT INTO `recommendations_posts` (`id`, `title`, `description`, `image`, `enabled`) VALUES
(1, 'Симонюк В.В. (test1)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(2, 'Симонюк В.В. (test2)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(3, 'Симонюк В.В. (test3)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(4, 'Симонюк В.В. (test4)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(5, 'Симонюк В.В. (test5)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(11) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `roles_id` (`roles_id`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `roles_id`, `alias`, `system`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, NULL, 'Super administrator', 'NO', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `translations_languages`
--

DROP TABLE IF EXISTS `translations_languages`;
CREATE TABLE IF NOT EXISTS `translations_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` varchar(5) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `translations_languages`
--

INSERT INTO `translations_languages` (`id`, `title`, `code`, `enabled`) VALUES
(1, 'English', 'EN_US', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `translations_values`
--

DROP TABLE IF EXISTS `translations_values`;
CREATE TABLE IF NOT EXISTS `translations_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translations_languages_id` int(11) NOT NULL,
  `original` varchar(255) NOT NULL,
  `translated` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `register_ts` int(11) DEFAULT NULL,
  `lastvizit_ts` int(11) DEFAULT NULL,
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `enabled`, `system`, `register_ts`, `lastvizit_ts`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 'YES', 'NO', 1350741357, 0, NULL, 0, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE IF NOT EXISTS `users_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `roles_id` (`roles_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users_roles`
--

INSERT INTO `users_roles` (`id`, `users_id`, `roles_id`) VALUES
(1, 1, 1);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`checked_out_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`modified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_4` FOREIGN KEY (`ref_table`) REFERENCES `core_tables` (`type`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `contacts_contacts`
--
ALTER TABLE `contacts_contacts`
  ADD CONSTRAINT `contacts_contacts_ibfk_1` FOREIGN KEY (`contacts_groups_id`) REFERENCES `contacts_groups` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Ограничения внешнего ключа таблицы `languages`
--
ALTER TABLE `languages`
  ADD CONSTRAINT `languages_ibfk_4` FOREIGN KEY (`checked_out_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `languages_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `languages_ibfk_6` FOREIGN KEY (`modified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `navigation_pages`
--
ALTER TABLE `navigation_pages`
  ADD CONSTRAINT `navigation_pages_ibfk_1` FOREIGN KEY (`checked_out_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_3` FOREIGN KEY (`modified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_4` FOREIGN KEY (`navigation_pages_id`) REFERENCES `navigation_pages` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `navigation_roles`
--
ALTER TABLE `navigation_roles`
  ADD CONSTRAINT `navigation_roles_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `navigation_roles_ibfk_3` FOREIGN KEY (`navigation_id`) REFERENCES `navigation_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `photogallery_albums`
--
ALTER TABLE `photogallery_albums`
  ADD CONSTRAINT `photogallery_albums_ibfk_1` FOREIGN KEY (`photogallery_albums_id`) REFERENCES `photogallery_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `photogallery_images`
--
ALTER TABLE `photogallery_images`
  ADD CONSTRAINT `photogallery_images_ibfk_1` FOREIGN KEY (`photogallery_albums_id`) REFERENCES `photogallery_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `roles_ibfk_2` FOREIGN KEY (`checked_out_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_ibfk_4` FOREIGN KEY (`modified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`checked_out_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_6` FOREIGN KEY (`modified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users_roles`
--
ALTER TABLE `users_roles`
  ADD CONSTRAINT `users_roles_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_roles_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
