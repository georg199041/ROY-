-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 27 2012 г., 11:50
-- Версия сервера: 5.1.62-community
-- Версия PHP: 5.3.9-ZS5.6.0

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `sunny_roy`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ref_table` varchar(255) DEFAULT NULL,
  `ref_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_agent` text NOT NULL,
  `comment` text,
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contents_posts` (`ref_table`,`ref_id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `comments_comments`
--

DROP TABLE IF EXISTS `comments_comments`;
CREATE TABLE IF NOT EXISTS `comments_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table` varchar(255) DEFAULT NULL,
  `table_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `user_agent` text NOT NULL,
  `comment` text,
  `status` enum('MODERATED','NOTVIEWED','REJECTED') NOT NULL DEFAULT 'NOTVIEWED',
  `created_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `comments_comments`
--

INSERT INTO `comments_comments` (`id`, `table`, `table_id`, `name`, `email`, `ip`, `user_agent`, `comment`, `status`, `created_ts`) VALUES
(1, 'photogallery_albums', 1, 'Пётр Фролов', 'email@mail.ru', '192.168.1.1', 'Mozzzzzila', '<p>1Авторская программа реабилитации наркозависимых включает в себя\n				проживание в деревянных домиках в природных условиях, а так же\n				использование природных оздоровительных процедур.</p>', 'MODERATED', 1353066529),
(2, 'photogallery_albums', 1, 'Пётр Фролов2', 'email@mail.ru', '192.168.1.1', 'Mozzzzzila', '<p>2Авторская программа реабилитации наркозависимых включает в себя\n				проживание в деревянных домиках в природных условиях, а так же\n				использование природных оздоровительных процедур.</p>', 'MODERATED', 1353066541);

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_contacts`
--

DROP TABLE IF EXISTS `contacts_contacts`;
CREATE TABLE IF NOT EXISTS `contacts_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contacts_groups_id` int(11) DEFAULT NULL,
  `type` enum('ADDRESS','MAINPHONE','PHONE','EMAIL','SKYPE','LATLNG','QRCODE','IMAGE','LINK') NOT NULL DEFAULT 'ADDRESS',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `contacts_groups_id` (`contacts_groups_id`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `contacts_contacts`
--

INSERT INTO `contacts_contacts` (`id`, `contacts_groups_id`, `type`, `title`, `alias`, `description`, `image`, `enabled`) VALUES
(1, 1, 'ADDRESS', 'Адрес базы в крыму', 'crimea_address', NULL, NULL, 'YES'),
(2, 1, 'MAINPHONE', 'Основной телефон', 'crimea_main_phone', '+38 (050) 545-33-69', NULL, 'YES'),
(3, 1, 'PHONE', 'Телефон', 'crimea_phone', '+38 (050) 545-30-69', NULL, 'YES'),
(4, 1, 'EMAIL', 'Эл. почта', 'crimea_email', 'admin@roy.com.uaфgetetre', NULL, 'YES'),
(5, 1, 'SKYPE', 'skype', 'crimea_skype', 'Che', NULL, 'YES'),
(6, 1, 'LATLNG', 'google', 'crimea_google', '44.836213,34.324379', NULL, 'YES'),
(7, 1, 'QRCODE', 'QR код', 'crimea_qr', NULL, '/uploads/contacts/crimea_qr.jpg', 'YES'),
(8, 2, 'ADDRESS', 'Адрес в Москве:', 'moscow_address', 'г.Москва, ул.Дубнинская д.14, к.2', NULL, 'YES'),
(9, 2, 'MAINPHONE', 'Телефон в москве', 'moscow_main_phone', '+7 (495) 668-12-73', NULL, 'YES'),
(10, 2, 'LATLNG', 'google', 'moscow_google', '48.382803,31.17461', NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contacts_groups`
--

DROP TABLE IF EXISTS `contacts_groups`;
CREATE TABLE IF NOT EXISTS `contacts_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `alias` (`alias`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `contacts_groups`
--

INSERT INTO `contacts_groups` (`id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, 'База в крыму', 'crimea_base', '<p>Живописное меcто Крыма расположено за селом Перевальное по пути из столицы Крыма - Симферополя - на Южный берег Крыма, трасса "Симферополь-Ялта".</p>\r\n<p>От авто- или железнодорожного вокзала доехать маршруткой "Симферополь-Перевальное" до остановки "Красная пещера"или троллейбусами 51, 52, 53 до остановки "Стадион".</p>\r\n<p><strong>Или позвоните нам, и мы Вас встретим.</strong></p>', 'YES'),
(2, 'Офис в Москве', 'moscow_office', NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_categories`
--

DROP TABLE IF EXISTS `contents_categories`;
CREATE TABLE IF NOT EXISTS `contents_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents_categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `alias` (`alias`),
  KEY `contents_categories_id` (`contents_categories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `contents_categories`
--

INSERT INTO `contents_categories` (`id`, `contents_categories_id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, NULL, 'Тестовая категория', 'tteesstt', 'des', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `contents_posts`
--

DROP TABLE IF EXISTS `contents_posts`;
CREATE TABLE IF NOT EXISTS `contents_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contents_categories_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `introtext` text,
  `fulltext` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `contents_categories_id` (`contents_categories_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `contents_posts`
--

INSERT INTO `contents_posts` (`id`, `contents_categories_id`, `title`, `alias`, `introtext`, `fulltext`, `enabled`) VALUES
(1, NULL, 'О клубе', 'about_club', '', '<h3>Спортивно-оздоровительный клуб &laquo;Рой&raquo; предлагает комплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма, включающее в себя:</h3>\r\n<br />1. Профилактику и реабилитацию зависимостей любых видов (алко- и наркозависимостей, консультации психолога, лечение наркомании);<br /><br />2. Курс восстановления после перенесенных травм суставов и сухожилий, при ослаблении организма, связанного с малоподвижным образом жизни и длительной работой на персональном компьютере;<br /><br />3. Общее оздоровление с применением Индотебетской и Старославянской практик с использованием:<br /><br />-&nbsp; Лекарственных растений Крымских гор;<br /><br />-&nbsp; АПИ терапии (профилактика с применением пчелоукалывания);<br /><br />-&nbsp; Купание в живой воде горного водопада;<br /><br />-&nbsp; Массажные процедуры с применением масел природной среды и одновременной диагностикой организма;<br /><br />-&nbsp; Посещение бани в условиях уникальной природы;<br /><br />-&nbsp; Спортивные мероприятия (волейбол, мини-футбол, работа на спортивных снарядах; &middot;<br /><br />- Ознакомление с навыками рукопашного боя и отдельными приемами Восточных единоборств под руководством наставника.<br /><br />- Возможны конные экскурсии, поездки на морское побережье Крыма.<br />&nbsp;&nbsp;&nbsp;&nbsp; Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.<br /><br />&nbsp;&nbsp;&nbsp;&nbsp; Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.<br /><br />&nbsp;&nbsp;&nbsp;&nbsp; Уделите несколько минут Вашего времени на изучение краткой информации о нашей методике лечения наркозависимости и реабилитационном центре в Крыму, посетите нашу фотогалерею, а Ваши последние сомнения окончательно развеют опытные специалисты, проконсультироваться с которыми можно по телефонам в Москве +7 495 668-12-73 и Украине +38 050 545-33-69.<br />&nbsp;\r\n<h1>Базовый лагерь клуба</h1>\r\n<h3>Реабилитационный центр и жизнь среди природы</h3>\r\n&nbsp;&nbsp;&nbsp;&nbsp; Авторская программа реабилитации наркозависимых включает в себя проживание в деревянных домиках в природных условиях, а также использование природных оздоровительных процедур.<br /><br />&nbsp;&nbsp;&nbsp;&nbsp; На территории лагеря оборудована баня, речная купель, спортивная площадка. Проживание и столовая расположены в комфортабельных домиках "финского типа". Жилые помещения центра имеют все условия для круглогодичной реабилитации наркозависимых и лечения наркомании. Спортивный зал с мягким покрытием предназначен для круглогодичного использования и расположен в утепленных палатках армейского типа. В зимний период жилые помещения обогреваются русскими печами.<br />&nbsp;\r\n<h2>Спортивно-оздоровительный клуб</h2>\r\n<h3>Реабилитация - Оздоровление - Исцеление</h3>\r\n&nbsp;&nbsp;&nbsp;&nbsp; Это не просто девиз - это практика восстановления здоровья и жизненной энергии через общение с Природой и следования её законам.<br /><br />&nbsp;&nbsp;&nbsp;&nbsp; Уникальная программа реабилитации зависимых от психоактивных веществ защищена Свидетельством регистрации авторского права №23593 Министерства образования и науки Украины, Государственным департаментом интеллектуальной собственности.', 'YES'),
(3, NULL, 'МИССИЯ И ЦЕЛИ', 'mission-and-goals', NULL, '<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <h2>Заголовок 2 уровня. Спортивный клуб «Рой»</h2>\r\n        <p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма</h3>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ol>\r\n            <li>Профилактику и реабилитацию зависимостей любых видов (алко- и наркозависимостей, консультации психолога, лечение наркомании).</li>\r\n            <li>Курс восстановления после <a href="">перенесенных травм</a> суставов и сухожилий, при ослаблении организма, связанного с малоподвижным образом жизни и длительной работой на персональном компьютере.</li>\r\n            <li>Общее оздоровление с применением Индотебетской и Старославянской <a href="">практик с использованием.</a></li>\r\n        </ol>\r\n        <p>Kомплексное оздоровление по уникальной методике с учетом индивидуальных особенностей организма:</p>\r\n        <ul>\r\n            <li>Лекарственных растений Крымских гор;</li>\r\n            <li>АПИ терапии (профилактика с применением пчелоукалывания);</li>\r\n            <li>Купание в живой воде горного водопада;</li>\r\n            <li>Массажные процедуры с применением масел природной среды и одновременной диагностикой организма.</li>\r\n        </ul>\r\n        <h3>Заголовок 3 уровня. Kомплексное оздоровление</h3>\r\n        <p>Методика, <strong>применяемая для реабилитации</strong> наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>\r\n        <blockquote><p>Цитата. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни.</p></blockquote>\r\n        <p>Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов. Методика, применяемая для реабилитации наркозависимых и лечения наркоманов.</p>', 'YES'),
(4, NULL, 'База клуба', 'club_base', '', '<p>База СК &laquo;РОЙ&raquo;, расположена в уникальном природном заповеднике &ndash; <a href="http://maps.google.com.ua/maps?q=44.858867,34.331294&amp;hl=ru&amp;sll=44.858911,34.331245&amp;sspn=0.066073,0.169086&amp;t=h&amp;z=13">урочище &laquo;Красная пещера&raquo;</a>, в условиях полной социальной изоляции, на берегу горной реки, поблизости от водопада &laquo;Су-Учхан&raquo;. Высота над уровнем моря 350 м.</p>\r\n<p>Участники программы проживают в деревянных домиках вместе с воспитателями-инструкторами.</p>\r\n<p>На территории базы расположен пищеблок, туалеты-септики, волейбольная и баскетбольная площадки, спортивный уголок для силовых упражнений, инвентарь для настольного тенниса.</p>\r\n<p>На берегу ручья расположена русская баня на дровах с купелью. Естественный природный быт лагеря подчеркивают фруктовый сад, виноградник, огород, собственная пасека и минимальное животноводческое хозяйство (козы и куры).</p>', 'YES'),
(5, NULL, 'Методика', 'methodology', '<iframe frameborder="0" height="315" src="http://www.youtube.com/embed/oemVaveWnj0" width="560"></iframe>', '<p>Программа предназначена для людей, страдающих физиологической и психологической зависимостью от психоактивных веществ (в т.ч. алкоголя) любой степени тяжести, а также имеющие другие зависимости (компьютер, азартные игры, секс и пр.). В программе могут принимать участие мужчины и женщины от 16 до 50 лет, жители Украины и граждане других стран.<br /><br /></p>\r\n<h3>Составляющие элементы программы</h3>\r\n<h4>Элемент №1</h4>\r\n<p>Купирование абстинентного синдрома, проведение психофизической реабилитации пациента в условиях социальной изоляции с использованием природных факторов, отличающейся тем, что снятие наркозависимости у пациента, проводят на трех уровнях:</p>\r\n<ul>\r\n<li>физиологическом;</li>\r\n<li>эмоционально-психологическом;</li>\r\n<li>ментальном;</li>\r\n</ul>\r\n<p>с использованием внутреннего потенциала самовосстановления и развитием у пациента новой потребности &ndash; стремления к творчеству.</p>\r\n<h4>Элемент №2</h4>\r\n<p>При снятии физиологической наркозависимости, проводят детоксикацию организма пациента без использования медикаментозных средств и исключают употребление пациентом наркотических средств на весь период реабилитации, кроме того, проводят очистительное питание.<br /><br /></p>\r\n<h4>Элемент №3</h4>\r\n<p>При снятии эмоционально-психологической наркозависимости, формируют привычку получения ярких позитивных эмоций от действий, не связанных с употреблением наркотиков, а также формируют привычку творческого, активного и эффективного решения психоэмоциональных проблем, исключая при этом жесткий гипноз и кодирование пациента.</p>\r\n<h4>Элемент №4</h4>\r\n<p>Снятие ментальной наркозависимости выполняют путем изоляции пациента от привычной социальной среды и формирования нового мировоззрения, включающего установки на смену привычной социальной среды и противодействие ее соблазнам, исключая при этом &laquo;промывание мозгов&raquo; и навязывание религиозно-идеологических стереотипов.</p>', 'YES'),
(6, NULL, 'Сущность программы', 'program', '', '<h3>Этап № 1. Работа с телом</h3>\r\n<h4>Акцент на снятие физической зависимости.</h4>\r\n<p>На этом этапе проводится первичная детоксикация организма, а в тяжелых случаях &ndash; снятие острого абстинентного синдрома. При очистке организма используются настои из экологически чистых крымских трав, натуральные масла, настойки на сыворотке, горный мед и другие продукты пчеловодства, морская соль.</p>\r\n<p>Основные оздоровительные процедуры &ndash; терморегуляция (купание в водопаде и горной реке, русская баня), массаж, лечебное дыхание ( в том числе с водяным затвором), прием травяных настоев седативного действия. Сон на пчелиной семье в специально оборудованном помещении.</p>\r\n<h3>Этап № 2. Восстановление нормального психоэмоционального состояния</h3>\r\n<h4>Акцент на снятие психологической&nbsp; зависимости.</h4>\r\n<p>На этом этапе основной&nbsp; задачей является выработка позитивного эмоционально-психологического&nbsp; настроя. Единение с природой, прогулки по горному лесу, купание в водопаде, встреча восхода и захода солнца в горах, совместный труд, беседы и песни у костра вызывают душевную радость и включают механизм выработки организмом естественных эндорфинов.</p>\r\n<p>Продолжается работа над телом &ndash; очистка печени и крови, основном с использованием рефлексотерапии &ndash; апипунктура (постановка пчел на биоактивные точки в соответствии с принципами китайской медицины, массаж с использованием натуральных масел.</p>\r\n<h3>&nbsp;</h3>\r\n<h3>Этап № 3. Восстановление базовых ценностей</h3>\r\n<h4>Акцент на снятие ментальной зависимости.</h4>\r\n<p>Основная задача этого этапа &ndash; пробуждение веры в самого себя, в свое Божественное начало, осознание своего предназначения.</p>\r\n<p>Групповые тренинги и индивидуальные занятия с психологом приводят к осознанию человеком своей социальной реализации, жизненных целей и планов на будущее.</p>\r\n<p>Продолжается работа с телом &ndash; комплекс упражнений реабилитационно &ndash; тренировочной методики Голтиса (<a href="http://www.goltis.us/">www.goltis.us</a>), комплексы преобразования связок, суставов и сухожилий.<br /><br /></p>\r\n<h3>Этап № 4. Закрепление</h3>\r\n<h4>Закрепление полученных изменений.</h4>\r\n<p>Идет работа над собой с учетом индивидуальных проблемных и недоработанных аспектов, а так же с учетом планов на будущее, выстроенных бывшим зависимым. Консультации психолога с родными бывшего зависимого, по телефону или на очной встрече, с целью принятия вновь возрожденного человека в семью, не вторгаясь в его личную жизнь.</p>', 'YES'),
(7, NULL, 'Результаты прохождения программы', 'findings', '', '<p><strong><span style="text-decoration: underline;">На первом этапе</span></strong> проходит детоксикация организма без использования медикаментов, исключительно на основе использования природных компонентов, снимаются депрессивные состояния, нормализуется аппетит и сон.</p>\r\n<p><strong><span style="text-decoration: underline;">На 2-м этапе</span></strong> вырабатывается позитивный эмоционально &ndash; психологический настой, включается выработка организмом естественных эндорфинов. Опытные наставники &ndash; психологи помогают решать личные проблемы, мешавшие нормальной жизни человека в социуме.</p>\r\n<p><strong><span style="text-decoration: underline;">На 3-м этапе</span></strong> делается акцент на снятии ментальной зависимости, человек обретает новую опору в жизни на основании вновь выстроенных ценностей.</p>\r\n<p><strong><span style="text-decoration: underline;">На 4-м этапе</span></strong> формируются планы на будущее, четко обозначается мотивационная программа для возвращения пациента в социум.</p>', 'YES'),
(8, NULL, 'Расписание дня в лагере', 'schedule', '', '<table style="width: 650px;" border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>6-30</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>подъем.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>6-30&nbsp; &nbsp;7-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>гигиенические процедуры.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>7-00 &nbsp;&nbsp;8-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>гимнастика для суставов и пластика тела.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>8-00&nbsp; &nbsp;9-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>прогулка по горному лесу, купание в водопаде, посещение целебного&nbsp; горного источника.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>9-00&nbsp; &nbsp;9-30</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>завтрак.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>9-30 &nbsp;&nbsp;10-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>свободное время, отдых.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>10-00 13-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>работы по жизнеобеспечению и благоустройству лагеря, забота о животных, огород и пр.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>13-00 14-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>свободное время, отдых.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>14-00 15-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>обед.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>15-00 17-30</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>свободное время, отдых (в распоряжении лагеря есть ТВ и библиотека).</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>17-30 19-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>тренировка по методике Голтиса (физические упражнения без использования утяжелений), индо-тибетские практики укрепления суставов, связок и сухожилий.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>19-00 20-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>русская баня.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>20-00 20-30</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>ужин.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>20-30 22-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>свободное время, отдых.</em></p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="102">\r\n<p><strong><em>22-00</em></strong></p>\r\n</td>\r\n<td valign="top" width="548">\r\n<p><em>отбой.</em></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p><em>&nbsp;</em></p>\r\n<p><em>Такой распорядок продолжается с понедельника по субботу. </em></p>\r\n<p><em>В воскресение &ndash; отдых на берегу моря или поход в горы с проводником.</em></p>', 'YES'),
(9, NULL, 'Документы', 'documentation', '', '<p>Способ реабилитации наркозависимости, используемый в программе СК &laquo;РОЙ&raquo; защищен патентом № 41030 от 27.04.2009 г., лицензия МОЗ Украины&nbsp; АВ № 565544, регистрация 02.09.2010 г.<br /><br /></p>', 'YES'),
(10, NULL, 'Рекомендации', 'recommendations', '', '<h3 style="text-align: center;">Республиканский наркологический диспансер АР Крым</h3>\r\n<p><br />Спортивно-оздоровительный клуб "РОЙ" - зрелое реабилитационное учреждение, предоставляющее наркозависимым помощь на этапах реадаптаци, реабилитации и дальнейшей ресоциализации.</p>\r\n<p>В клубе разработана оригинальная 4-х шаговая методика реабилитаци, основанная на физиотерапевтических природных процедурах, психологическом воздействии средой и коллективной трудотерапией.</p>\r\n<p>В реабилитационном процессе используются бывшие пациенты - инструктора. Пациенты реабилитационной программы живут ощущением единой команды, проживают в общих палатках с инструкторами. Медицинские препараты в программе не применяются, за исключением сборов трав и продуктов пчеловодства.</p>\r\n<p>Клуб "РОЙ" обеспечил реабилитационную работу европейского уровня, что отличает его от многих реабилитационных наркологических учреждений. Для Украины реабилитационная программа клуба "РОЙ" - один из ростков наркологии будущего.<br /><br /><br /></p>\r\n<h3 style="text-align: center;">Кафедра психиатрии, наркологии и психотерапии Крымского медицинского университета им. С.И.Георгиевского</h3>\r\n<p><br />Предлагаемая спортивно-оздоровительным клубом "РОЙ" программа работы с лицами, зависимыми от психоактивных веществ, а также зависимых от других объектов (компьютера, азартных игр, секса и т.д.) включает в себя комплекс реабилитации и ресоциализации, которые хорошо согласуются с требованиями современной психотерапевтической, клинической практики. Программа является эффективной при снятии основных наркологических синдромов, реабилитации и последующей социальной адаптации.</p>\r\n<p>В частности, реабилитационная программа включает в себя широкий арсенал приемов биологической терапии, физиотерапии, индивидуальной и групповой психотерапии. Фармакотерапевтическое вмешательство не применяется. Лишь в тяжелых случаях при необходимости проводится детоксикационная (дезинтоксикационная), заместительная, а также ургентная (неотложная) терапия.</p>\r\n<p>Отличительной чертой программы клуба "РОЙ", созданной ее руководителем Линевым Павлом Владимировичем, является полное погружение в необычную для большинства зависимых среду. В ней "природный образ жизни" и восточные практики оздоровления и физического развития (адаптированные для нашего менталитета) создают благоприятный фон для проведения процедур групповой психотерапии и физиотерапевтического воздействия.</p>\r\n<p>Данную программу модно рекомендовать для реабилитации пациентов с легкой и средней степенью зависимости, а в некоторых случаях - и при тяжелых формах зависимости, в том числе прошедшим курс стационарного лечения в специализированных наркологических учреждениях. Программа также рекомендуется для оздоровления, реабилитации лиц с различными невротическими расстройствами и психологическими проблемами в подростковом возрасте.</p>', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `core_sources`
--

DROP TABLE IF EXISTS `core_sources`;
CREATE TABLE IF NOT EXISTS `core_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `core_sources`
--

INSERT INTO `core_sources` (`id`, `name`) VALUES
(1, 'contents_categories'),
(2, 'contents_posts');

-- --------------------------------------------------------

--
-- Структура таблицы `default_sources`
--

DROP TABLE IF EXISTS `default_sources`;
CREATE TABLE IF NOT EXISTS `default_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `default_sources`
--

INSERT INTO `default_sources` (`id`, `name`) VALUES
(3, 'contacts_contacts'),
(1, 'contents_categories'),
(2, 'contents_posts');

-- --------------------------------------------------------

--
-- Структура таблицы `documents_posts`
--

DROP TABLE IF EXISTS `documents_posts`;
CREATE TABLE IF NOT EXISTS `documents_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `documents_posts`
--

INSERT INTO `documents_posts` (`id`, `title`, `description`, `image`, `enabled`) VALUES
(1, 'Симонюк В.В. (test1)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(2, 'Симонюк В.В. (test2)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(3, 'Симонюк В.В. (test3)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(4, 'Симонюк В.В. (test4)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(5, 'Симонюк В.В. (test5)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(6, 'цкукпекыр', 'увепквриеунтрукн', '', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` varchar(2) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) NOT NULL DEFAULT '0',
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_pages`
--

DROP TABLE IF EXISTS `navigation_pages`;
CREATE TABLE IF NOT EXISTS `navigation_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `navigation_pages_id` int(11) DEFAULT NULL,
  `label` varchar(255) NOT NULL,
  `type` enum('URI','MVC') NOT NULL DEFAULT 'URI',
  `uri` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `controller` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `params` text,
  `route` varchar(255) DEFAULT NULL,
  `reset_params` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `encode_url` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `order` int(11) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`),
  KEY `navigation_pages_id` (`navigation_pages_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Дамп данных таблицы `navigation_pages`
--

INSERT INTO `navigation_pages` (`id`, `navigation_pages_id`, `label`, `type`, `uri`, `action`, `controller`, `module`, `params`, `route`, `reset_params`, `encode_url`, `order`, `enabled`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(2, NULL, 'Главное меню', 'URI', '', '', '', '', '', '', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1352715212, NULL, 1353940725),
(3, 2, 'Главная', 'MVC', NULL, 'index', 'index', 'default', NULL, NULL, 'YES', 'NO', 1, 'YES', NULL, NULL, NULL, 1352715271, NULL, 1352729558),
(4, 2, 'О клубе', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"about_club"}', NULL, 'YES', 'NO', 2, 'YES', NULL, NULL, NULL, 1352715319, NULL, 1352794427),
(5, 2, 'Оздоровление и реабилитация', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"methodology"}', '', 'YES', 'NO', 3, 'YES', NULL, NULL, NULL, 1352715581, NULL, 1353943224),
(6, 2, 'База клуба', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"club_base"}', NULL, 'YES', 'NO', 4, 'YES', NULL, NULL, NULL, 1352723440, NULL, 1352794438),
(7, 2, 'Контакты', 'MVC', NULL, 'index', 'index', 'contacts', NULL, 'contacts', 'YES', 'NO', 5, 'YES', NULL, NULL, NULL, 1352723500, NULL, 1353492449),
(8, 4, 'Слово Руководителя', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"according-to-head-of"}', NULL, 'YES', 'NO', 1, 'YES', NULL, NULL, NULL, 1352818173, NULL, NULL),
(9, 4, 'История', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"history"}', NULL, 'YES', 'NO', 2, 'YES', NULL, NULL, NULL, 1352818248, NULL, 1352818340),
(10, 4, 'Миссия и цели', 'MVC', NULL, 'view-static', 'index', 'contents', '{"alias":"mission-and-goals"}', NULL, 'YES', 'NO', 3, 'YES', NULL, NULL, NULL, 1352818297, NULL, NULL),
(11, 4, 'Документы', 'MVC', '', 'documents', 'index', 'contents', '{"alias":"documentation"}', '', 'YES', 'NO', 4, 'YES', NULL, NULL, NULL, 1352818366, NULL, 1353944750),
(12, 4, 'Персонал', 'MVC', '', 'index', 'index', 'staff', '', 'staff', 'YES', 'NO', 5, 'YES', NULL, NULL, NULL, 1352818409, NULL, 1354001958),
(13, 4, 'Рекомендации', 'MVC', NULL, 'index', 'index', 'recommendations', NULL, 'recommendations', 'YES', 'NO', 6, 'YES', NULL, NULL, NULL, 1352818440, NULL, 1352991392),
(14, 6, 'Фотогалерея', 'MVC', NULL, 'index', 'index', 'photogallery', NULL, 'photogallery', 'YES', 'NO', 7, 'YES', NULL, NULL, NULL, 1353008102, NULL, 1353490087),
(15, 5, 'Сущность программы', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"program"}', '', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1353943979, NULL, NULL),
(16, 5, 'Результаты прохождения программы', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"findings"}', '', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1353944107, NULL, NULL),
(17, 5, 'Расписание дня в лагере', 'MVC', '', 'view-static', 'index', 'contents', '{"alias":"schedule"}', '', 'YES', 'NO', NULL, 'YES', NULL, NULL, NULL, 1353944305, NULL, NULL);

--
-- Триггеры `navigation_pages`
--
DROP TRIGGER IF EXISTS `BEFORE_INSERT_navigation_pages`;
DELIMITER //
CREATE TRIGGER `BEFORE_INSERT_navigation_pages` BEFORE INSERT ON `navigation_pages`
 FOR EACH ROW BEGIN
	SET `NEW`.`created_ts` = UNIX_TIMESTAMP();
	IF `NEW`.`checked_out_by` IS NOT NULL THEN
	    SET `NEW`.`checked_out_ts` = UNIX_TIMESTAMP();
	ELSE
	    SET `NEW`.`checked_out_ts` = NULL;
	END IF;
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `BEFORE_UPDATE_navigation_pages`;
DELIMITER //
CREATE TRIGGER `BEFORE_UPDATE_navigation_pages` BEFORE UPDATE ON `navigation_pages`
 FOR EACH ROW BEGIN
	SET `NEW`.`modified_ts` = UNIX_TIMESTAMP();
	IF `NEW`.`checked_out_by` IS NOT NULL THEN
	    SET `NEW`.`checked_out_ts` = UNIX_TIMESTAMP();
	ELSE
	    SET `NEW`.`checked_out_ts` = NULL;
	END IF;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Структура таблицы `navigation_roles`
--

DROP TABLE IF EXISTS `navigation_roles`;
CREATE TABLE IF NOT EXISTS `navigation_roles` (
  `navigation_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  `type` enum('ALLOW','DENY') NOT NULL DEFAULT 'ALLOW',
  KEY `navigation_id` (`navigation_id`),
  KEY `roles_id` (`roles_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `navigation_roles`
--

INSERT INTO `navigation_roles` (`navigation_id`, `roles_id`, `type`) VALUES
(2, 1, 'ALLOW');

-- --------------------------------------------------------

--
-- Структура таблицы `params_names`
--

DROP TABLE IF EXISTS `params_names`;
CREATE TABLE IF NOT EXISTS `params_names` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `params_types_id` int(11) NOT NULL,
  `params_sources_id` int(11) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `params_types_id` (`params_types_id`),
  KEY `params_sources_id` (`params_sources_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `params_names`
--

INSERT INTO `params_names` (`id`, `name`, `params_types_id`, `params_sources_id`, `enabled`) VALUES
(1, 'additional_param', 3, NULL, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `params_options`
--

DROP TABLE IF EXISTS `params_options`;
CREATE TABLE IF NOT EXISTS `params_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `params_names_id` int(11) NOT NULL,
  `option` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `params_names_id` (`params_names_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `params_relations`
--

DROP TABLE IF EXISTS `params_relations`;
CREATE TABLE IF NOT EXISTS `params_relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `params_relations_id` int(11) DEFAULT NULL,
  `core_sources_id` int(11) NOT NULL,
  `core_sources_parentid` int(11) DEFAULT NULL,
  `params_names_id` int(11) NOT NULL,
  `inheritable` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `core_sources_id` (`core_sources_id`),
  KEY `params_names_id` (`params_names_id`),
  KEY `params_relations_id` (`params_relations_id`),
  KEY `core_sources_parentid` (`core_sources_parentid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `params_relations`
--

INSERT INTO `params_relations` (`id`, `params_relations_id`, `core_sources_id`, `core_sources_parentid`, `params_names_id`, `inheritable`) VALUES
(1, NULL, 2, NULL, 1, 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `params_sources`
--

DROP TABLE IF EXISTS `params_sources`;
CREATE TABLE IF NOT EXISTS `params_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `core_sources_id` int(11) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `core_sources_id` (`core_sources_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `params_types`
--

DROP TABLE IF EXISTS `params_types`;
CREATE TABLE IF NOT EXISTS `params_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `source_required` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `params_types`
--

INSERT INTO `params_types` (`id`, `title`, `code`, `source_required`, `enabled`) VALUES
(1, NULL, 'SELECT', 'YES', 'YES'),
(2, NULL, 'MULTISELECT', 'YES', 'YES'),
(3, NULL, 'TEXT', 'NO', 'YES'),
(4, NULL, 'TEXTAREA', 'NO', 'YES'),
(5, NULL, 'CHECKBOX', 'NO', 'YES'),
(6, NULL, 'MULTICHECKBOX', 'YES', 'YES'),
(7, NULL, 'WYSWYG', 'NO', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `params_values`
--

DROP TABLE IF EXISTS `params_values`;
CREATE TABLE IF NOT EXISTS `params_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `core_sources_id` int(11) NOT NULL,
  `params_names_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `photogallery_albums`
--

DROP TABLE IF EXISTS `photogallery_albums`;
CREATE TABLE IF NOT EXISTS `photogallery_albums` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photogallery_albums_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` text,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `photogallery_albums_id` (`photogallery_albums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `photogallery_albums`
--

INSERT INTO `photogallery_albums` (`id`, `photogallery_albums_id`, `title`, `alias`, `description`, `enabled`) VALUES
(1, NULL, 'Тяжка работа мысли (test1)', 'test1', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(2, NULL, 'Журчит ручей (test2)', 'test2', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(3, NULL, 'Далекие дали (test3)', 'test3', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(4, NULL, 'Шаолинь как он есть (test4)', 'test4', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(5, NULL, 'Тыгдынские кони (test5)', 'test5', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES'),
(6, NULL, 'Дали но чуть поближе (test6)', 'test6', '<p>Описание альбома, если нужно. Методика, применяемая для реабилитации\n		наркозависимых и лечения наркоманов, не связана с медицинскими\n		препаратами и не имеет аналогов, защищена Авторским Свидетельством.</p>', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `photogallery_images`
--

DROP TABLE IF EXISTS `photogallery_images`;
CREATE TABLE IF NOT EXISTS `photogallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photogallery_albums_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  `cover` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `created_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `photogallery_albums_id` (`photogallery_albums_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `photogallery_images`
--

INSERT INTO `photogallery_images` (`id`, `photogallery_albums_id`, `title`, `description`, `image`, `enabled`, `cover`, `created_ts`) VALUES
(1, 1, 'test cover1', '<p>1Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100),
(2, 2, 'test cover2', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album2/image.jpg', 'YES', 'NO', 200),
(3, 3, 'test cover3', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album3/image.jpg', 'YES', 'NO', 300),
(4, 4, 'test cover4', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album4/image.jpg', 'YES', 'NO', 400),
(5, 5, 'test cover5', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album5/image.jpg', 'YES', 'NO', 400),
(6, 6, 'test cover6', '<p>Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album6/image.jpg', 'YES', 'NO', 400),
(7, 1, 'test cover2', '<p>2Описание фото, если нужно. Авторская программа реабилитации\n			наркозависимых включает в себя проживание в деревянных домиках в\n			природных условиях, а так же использование природных оздоровительных\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100),
(8, 1, 'test cover1', '<p>Описание фото, если нужно. Авторская программа реабилитации\r\n			наркозависимых включает в себя проживание в деревянных домиках в\r\n			природных условиях, а так же использование природных оздоровительных\r\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100),
(9, 1, 'test cover1', '<p>Описание фото, если нужно. Авторская программа реабилитации\r\n			наркозависимых включает в себя проживание в деревянных домиках в\r\n			природных условиях, а так же использование природных оздоровительных\r\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100),
(10, 1, 'test cover1', '<p>Описание фото, если нужно. Авторская программа реабилитации\r\n			наркозависимых включает в себя проживание в деревянных домиках в\r\n			природных условиях, а так же использование природных оздоровительных\r\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100),
(11, 1, 'test cover1', '<p>Описание фото, если нужно. Авторская программа реабилитации\r\n			наркозависимых включает в себя проживание в деревянных домиках в\r\n			природных условиях, а так же использование природных оздоровительных\r\n			процедур.</p>', '/uploads/photogallery/album1/image.jpg', 'YES', 'YES', 100);

-- --------------------------------------------------------

--
-- Структура таблицы `recommendations_posts`
--

DROP TABLE IF EXISTS `recommendations_posts`;
CREATE TABLE IF NOT EXISTS `recommendations_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `recommendations_posts`
--

INSERT INTO `recommendations_posts` (`id`, `title`, `description`, `image`, `enabled`) VALUES
(1, 'Симонюк В.В. (test1)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(2, 'Симонюк В.В. (test2)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(3, 'Симонюк В.В. (test3)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(4, 'Симонюк В.В. (test4)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(5, 'Симонюк В.В. (test5)', '<p>Врач-реабилитолог</p>\r\n<p>Методика, применяемая для реабилитации наркозависимых и лечения наркоманов, не связана с медицинскими препаратами и не имеет аналогов, защищена Авторским Свидетельством, а также достаточно эффективна, что подтверждено максимальным процентом возвращения зависимых к нормальной жизни. Наш центр расположен в горной части Крыма, в лесу, проживание осуществляется в деревянных домиках.</p>', '/uploads/recommendations/recommendation_1.jpg', 'YES'),
(6, 'цкукпекыр', 'увепквриеунтрукн', '', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(11) DEFAULT NULL,
  `alias` varchar(255) NOT NULL,
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `roles_id` (`roles_id`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `created_by` (`created_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `roles_id`, `alias`, `system`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, NULL, 'Super administrator', 'NO', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `staff_staff`
--

DROP TABLE IF EXISTS `staff_staff`;
CREATE TABLE IF NOT EXISTS `staff_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `skype` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `staff_staff`
--

INSERT INTO `staff_staff` (`id`, `name`, `phone`, `email`, `skype`, `description`, `image`, `enabled`) VALUES
(1, 'Василий иванович Чапаев (test1)', '+380(50)539-18-25', 'admin@roi.com.ua', 'Che', 'Командир Красной армии, стратег, плавец, жнец, щвец и на дуде игрец, а в общей сложности.', '/uploads/photo_6.jpg', 'YES'),
(2, 'Василий иванович Чапаев (test2)', '+380(50)539-18-25', 'admin@roi.com.ua', 'Che', 'Командир Красной армии, стратег, плавец, жнец, щвец и на дуде игрец, а в общей сложности.', '/uploads/photo_6.jpg', 'YES'),
(3, 'Василий иванович Чапаев (test3)', '+380(50)539-18-25', 'admin@roi.com.ua', 'Che', 'Командир Красной армии, стратег, плавец, жнец, щвец и на дуде игрец, а в общей сложности.', '/uploads/photo_6.jpg', 'YES'),
(4, 'Василий иванович Чапаев (test4)', '+380(50)539-18-25', 'admin@roi.com.ua', NULL, 'Командир Красной армии, стратег, плавец, жнец, щвец и на дуде игрец, а в общей сложности.', '/uploads/photo_6.jpg', 'YES'),
(5, 'Василий иванович Чапаев (test5)', '+380(50)539-18-25', 'admin@roi.com.ua', 'Che', 'Командир Красной армии, стратег, плавец, жнец, щвец и на дуде игрец, а в общей сложности.', '/uploads/photo_6.jpg', 'YES'),
(6, 'цкукпекыр', '62716427583', 'admin@roi.com.ua', NULL, 'увепквриеунтрукн', '/uploads/photo_6.jpg', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `translations_languages`
--

DROP TABLE IF EXISTS `translations_languages`;
CREATE TABLE IF NOT EXISTS `translations_languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` varchar(5) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'YES',
  PRIMARY KEY (`id`),
  KEY `code` (`code`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `translations_languages`
--

INSERT INTO `translations_languages` (`id`, `title`, `code`, `enabled`) VALUES
(1, 'English', 'EN_US', 'YES');

-- --------------------------------------------------------

--
-- Структура таблицы `translations_values`
--

DROP TABLE IF EXISTS `translations_values`;
CREATE TABLE IF NOT EXISTS `translations_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `translations_languages_id` int(11) NOT NULL,
  `original` varchar(255) NOT NULL,
  `translated` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `register_ts` int(11) DEFAULT NULL,
  `lastvizit_ts` int(11) DEFAULT NULL,
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `enabled`, `system`, `register_ts`, `lastvizit_ts`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 'YES', 'NO', 1350741357, 0, NULL, 0, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users_roles`
--

DROP TABLE IF EXISTS `users_roles`;
CREATE TABLE IF NOT EXISTS `users_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `roles_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `roles_id` (`roles_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users_roles`
--

INSERT INTO `users_roles` (`id`, `users_id`, `roles_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users_users`
--

DROP TABLE IF EXISTS `users_users`;
CREATE TABLE IF NOT EXISTS `users_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `enabled` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `system` enum('YES','NO') NOT NULL DEFAULT 'NO',
  `register_ts` int(11) DEFAULT NULL,
  `lastvizit_ts` int(11) DEFAULT NULL,
  `checked_out_by` int(11) DEFAULT NULL,
  `checked_out_ts` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_ts` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_ts` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `created_by` (`created_by`),
  KEY `checked_out_by` (`checked_out_by`),
  KEY `modified_by` (`modified_by`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users_users`
--

INSERT INTO `users_users` (`id`, `email`, `password`, `enabled`, `system`, `register_ts`, `lastvizit_ts`, `checked_out_by`, `checked_out_ts`, `created_by`, `created_ts`, `modified_by`, `modified_ts`) VALUES
(1, 'admin@admin.com', 'e10adc3949ba59abbe56e057f20f883e', 'YES', 'NO', 1350741357, 0, NULL, 0, NULL, 0, NULL, 0),
(2, 'marina@sunny.net.ua', 'ce5225d01c39d2567bc229501d9e610d', 'YES', 'NO', 1353684342, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_3` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_ibfk_4` FOREIGN KEY (`ref_table`) REFERENCES `core_tables` (`type`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `contacts_contacts`
--
ALTER TABLE `contacts_contacts`
  ADD CONSTRAINT `contacts_contacts_ibfk_1` FOREIGN KEY (`contacts_groups_id`) REFERENCES `contacts_groups` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Ограничения внешнего ключа таблицы `languages`
--
ALTER TABLE `languages`
  ADD CONSTRAINT `languages_ibfk_4` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `languages_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `languages_ibfk_6` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `navigation_pages`
--
ALTER TABLE `navigation_pages`
  ADD CONSTRAINT `navigation_pages_ibfk_1` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_3` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `navigation_pages_ibfk_4` FOREIGN KEY (`navigation_pages_id`) REFERENCES `navigation_pages` (`id`) ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `navigation_roles`
--
ALTER TABLE `navigation_roles`
  ADD CONSTRAINT `navigation_roles_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `navigation_roles_ibfk_3` FOREIGN KEY (`navigation_id`) REFERENCES `navigation_pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `photogallery_albums`
--
ALTER TABLE `photogallery_albums`
  ADD CONSTRAINT `photogallery_albums_ibfk_1` FOREIGN KEY (`photogallery_albums_id`) REFERENCES `photogallery_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `photogallery_images`
--
ALTER TABLE `photogallery_images`
  ADD CONSTRAINT `photogallery_images_ibfk_1` FOREIGN KEY (`photogallery_albums_id`) REFERENCES `photogallery_albums` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `roles_ibfk_2` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `roles_ibfk_4` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`checked_out_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_6` FOREIGN KEY (`modified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users_roles`
--
ALTER TABLE `users_roles`
  ADD CONSTRAINT `users_roles_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_roles_ibfk_2` FOREIGN KEY (`roles_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users_users`
--
ALTER TABLE `users_users`
  ADD CONSTRAINT `users_users_ibfk_4` FOREIGN KEY (`checked_out_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_users_ibfk_5` FOREIGN KEY (`created_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_users_ibfk_6` FOREIGN KEY (`modified_by`) REFERENCES `users_users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
